// Train body

// Engineer's compartment

// Smoke stack

// Wheels

// Track
#define RAIL_WIDTH 0.25f
#define RAIL_HEIGHT 0.25f
#define RAIL_LENGTH 22.0f

// Ties

// Blocks
#define BOTTOM_BLOCK_SIZE 4.0f
#define MIDDLE_BLOCK_SIZE 2.0f
#define TOP_BLOCK_SIZE 1.0f
